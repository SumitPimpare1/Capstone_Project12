package com.starhealth.ecart.service;

import java.util.List;

import com.starhealth.ecart.entity.Cart;


public interface IcartService {

	public Cart addCart(Cart prod);
	public Cart updateCart(Cart prod);
	public Cart getCartProductById(int id);
	public List<Cart> getAllCartProducts();
	public void deleteCartProductById(int id);

}
