export class Employee{

    
    userName:string = "";
    password:string = "";
    



}

