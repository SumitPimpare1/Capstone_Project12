package com.starhealth.ecart.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data

@Entity
@Table(name="starhealth_cart")
public class Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
 
	private int productId;
	private String userName;
	private String productName;
	private double productPrice ;
	private String productImage;
}
