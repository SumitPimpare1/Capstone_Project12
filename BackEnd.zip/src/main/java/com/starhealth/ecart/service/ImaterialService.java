package com.starhealth.ecart.service;

import java.util.List;

import com.starhealth.ecart.entity.Material;

public interface ImaterialService {
	
	public Material addProduct(Material prod);
	public Material updateProduct(Material prod);
	public Material getProductById(int id);
	public List<Material> getAllProducts();
	public void deleteProductById(int id);
	
	
}
