package com.starhealth.ecart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecart.entity.Material;
import com.starhealth.ecart.repository.Imaterial;
@Service
public class ImaterialServiceImp implements ImaterialService {
	
	@Autowired
	Imaterial prodrepo;
	
	@Override
	public Material addProduct(Material prod) {
		return prodrepo.save(prod);
	}

	@Override
	public Material updateProduct(Material prod) {
		// TODO Auto-generated method stub
		return prodrepo.save(prod);
	}
	@Override
	public Material getProductById(int id) {
		// TODO Auto-generated method stub
		return prodrepo.findById(id).orElse(new Material()) ;
	}
	@Override
	public List<Material> getAllProducts() {
		// TODO Auto-generated method stub
		return prodrepo.findAll();
	}
	@Override
	public void deleteProductById(int id) {
		// TODO Auto-generated method stub
		prodrepo.deleteById(id); 
	}
	



}
