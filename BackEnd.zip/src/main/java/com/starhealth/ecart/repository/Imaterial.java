package com.starhealth.ecart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.ecart.entity.Material;

public interface Imaterial extends JpaRepository<Material, Integer>{

}
