package com.starhealth.ecart.service;

import com.starhealth.ecart.entity.User;

public interface IuserService {

	public User addUser(User user);

	public User getUserByName(String userName, String Domin);

}
