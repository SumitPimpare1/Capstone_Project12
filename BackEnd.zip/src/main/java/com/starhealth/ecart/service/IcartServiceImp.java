package com.starhealth.ecart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecart.entity.Cart;
import com.starhealth.ecart.repository.Icart;
@Service
public class IcartServiceImp implements IcartService{
	@Autowired
	Icart repocart;
	@Override
	public Cart addCart(Cart cart) {
		// TODO Auto-generated method stub
		return repocart.save(cart) ;
	}

	@Override
	public Cart updateCart(Cart cart) {
		// TODO Auto-generated method stub
		return repocart.save(cart) ;
	}

	@Override
	public Cart getCartProductById(int id) {
		// TODO Auto-generated method stub
		return repocart.findById(id).orElse(new Cart());
	}

	@Override
	public List<Cart> getAllCartProducts() {
		// TODO Auto-generated method stub
		return repocart.findAll();
	}

	@Override
	public void deleteCartProductById(int id) {
		// TODO Auto-generated method stub
		repocart.deleteById(id);
	}

}
