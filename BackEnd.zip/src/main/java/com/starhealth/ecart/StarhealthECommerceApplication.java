package com.starhealth.ecart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarhealthECommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarhealthECommerceApplication.class, args);
	}

}
