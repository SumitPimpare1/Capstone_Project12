import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName: string="";
  password: string="";
  router: any;
  role: string="";
  

  constructor(private service:EmployeeService,  router: Router) { }

  ngOnInit(): void {
  }

getFormData(data:any){

  // this.router.navigate(['./displayall']);

  this.userName = data.userName;
  this.password = data.password;
  this.role = data.role;


  console.log(this.userName +" "+ this.password +" "+this.role);

  // onLoginClick(){
  //   this.router.navigate(['./displayall']);
  // }

  if(this.userName == "Sumit" && this.password == "112233" && this.role=="User"){
    // alert("alert msg ")

    // route to displayall
   this.router.navigate(['./displayall']);  //routerLink in html
   
  }

 }

}
