import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Application';
  service: any;
  userName: any;
  password: any;
  router: any;

  insertFormData(data:Employee){

    this.service.insert(data);
  
    alert("Userdata is here");
  
  }
  // getFormData(data:any){

  //   this.userName = data.userName;
  //   this.password = data.password;
  
  //   console.log(this.userName +" "+ this.password);

  //   onLoginClick()
  //     this.router.navigate(['./displayall']);
   
  
  //   if(this.userName == "Sumit" && this.password == "112233"){
  //     alert("alert msg ")
  
  //     // route to displayall
  //   //  this.router.navigate(['./displayall']);  //routerLink in html
     
  //   }
    
}


  

  

  // function onLoginClick() {
    //   throw new Error('Function not implemented.')}


function onLoginClick() {
  throw new Error('Function not implemented.');
}

