import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeleteComponent } from './delete/delete.component';
import { DisplayallComponent } from './displayall/displayall.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  
      {path:'login',component:LoginComponent},
      {path:'displayall',component:DisplayallComponent},
      {path:'register',component:RegisterComponent},
      {path:'header',component:HeaderComponent},
      {path:'update/:id',component:UpdateComponent},
      {path:'update',component:UpdateComponent},
      {path:'footer',component:FooterComponent},
      {path:'delete',component:DeleteComponent},
      {path:'login',component:LoginComponent},
      {path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
