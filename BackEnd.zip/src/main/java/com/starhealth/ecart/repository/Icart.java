package com.starhealth.ecart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.ecart.entity.Cart;

public interface Icart extends JpaRepository<Cart, Integer> {
	

}
